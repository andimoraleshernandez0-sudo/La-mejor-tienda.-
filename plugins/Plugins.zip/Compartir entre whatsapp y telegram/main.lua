if service.click({
{"%Pulsación larga",
"%Atrás",
"Más opciones",
"Compartir",
"Telegram",
}
})
return true
end

return true