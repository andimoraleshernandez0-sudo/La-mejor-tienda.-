--dictado con puntuación mediante sustitución de traducción del inglés al español, Incluye Tabla de Sustituciones.
require "import"
import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "android.speech.RecognizerIntent"
import "java.util.Locale"
import "android.content.Intent"

require "import"
import "com.androlua.*"
import "java.util.Locale"
import "android.net.Uri"
import "android.text.Html"
local translationResults = {} -- Tabla para almacenar los resultados de la traducción

-- Tabla de sustituciones
local substitutions = {
    ["chino"] = "Jieshuo",
["china"] = "Jieshuo",
["soy muy caliente"] = "tengo mucho calor",
    -- Agrega más sustituciones aquí
}

function capWords(str)
    return str:gsub("(%S+)", function(word)
        return word:gsub("%a", string.upper, 1)
    end)
end

function addPunctuation(text)
    local lastChar = text:sub(-1)
    local punctuation = { ".", "!", "?" }
    local hasPunctuation = false

    for _, p in ipairs(punctuation) do
        if lastChar == p then
            hasPunctuation = true
            break
        end
    end

    if not hasPunctuation then
        text = text .. "."
    end

    return text
end

function applySubstitutions(text)
    for word, replacement in pairs(substitutions) do
        text = text:gsub(word, replacement)
    end
    return text
end

function kill()
    speechRecognizer.destroy()
    speechRecognizer = nil
    return true
end

function startListening()
    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
    speechListener = RecognitionListener{
        onResults = function(results)
            data = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if data ~= nil and data.size() > 0 then
                local originalText = capWords(data.get(0))
                translateText(originalText, "es", "en") -- Traducción del español al inglés
            end
            kill()
        end,
        onError = function()
            kill()
            startListening()
        end
    }
    recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName())
    speechRecognizer.startListening(recognizerIntent)
    speechRecognizer.setRecognitionListener(speechListener)
end

function translateText(text, sourceLang, targetLang)
    url = "https://translate.google.com/m?sl="..sourceLang.."&tl="..targetLang.."&hl="..Locale.getDefault().getLanguage().."&q="..Uri.encode(text)

    Http.get(url, function(status, result)
        if status == 200 then
            local translation = tostring(Html.fromHtml(result:match('<div class="result%-container">([^<]+)</div>')))
            translationResults[sourceLang] = translation -- Almacenar la traducción en la tabla
            if targetLang == "en" then
                translateText(translation, targetLang, "es") -- Traducción inversa del inglés al español
            else
                translationResults[targetLang] = translation -- Almacenar la traducción inversa en la tabla
                printTranslatedResult() -- Imprimir el resultado final en español
            end
        else
            print("Error :-(")
        end
    end)
end

function printTranslatedResult()
    if translationResults["es"] ~= nil and translationResults["en"] ~= nil then
        local translatedResult = addPunctuation(translationResults["en"])
        translatedResult = applySubstitutions(translatedResult)
service.paste(translatedResult.."\n")
        service.speak(""..translatedResult)
else
print("No se encontró traducción en español e inglés.")
end
end
startListening()