if service.click({
{"%Pulsación larga",
"https://chat.whatsapp.com/E6FfD4n5JuTJmHVUlQd2GCentra al grupo accesibilidad para todos de WhatsApp",
}
})
return true
end

return true