if service.click({
{"‎1×|‎1.5×|‎2×",
}
})
return true
end

return true