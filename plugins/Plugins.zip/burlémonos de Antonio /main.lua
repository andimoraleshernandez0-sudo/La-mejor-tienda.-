require "import"
import "android.widget.*"
import "com.androlua.*"
import "android.content.Context"
import "android.os.Vibrator"
import "android.content.Intent"
import "android.net.Uri"

local bienvenidaMensaje = "¡para unirte a esta comunidad debes de aguantar ofensas, burlas etcétera etcétera ! Para unirte a nuestro grupo, sigue el enlace que compartiremos a continuación y forma parte de este espacio de exclusión, y bullying de todo tipo ."
local enlaces = {
  "Grupo de WhatsApp, a burlarnos de Antonio López el gordo ",
}

local context = activity or service
local vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)
vibrator.vibrate(100)

layout = {
  LinearLayout,
  orientation = LinearLayout.VERTICAL,
  {
    TextView,
    text = bienvenidaMensaje,
    textSize = "20sp",
    gravity = 17,
    padding = "16dp",
  },
  {
    GridView,
    id = "grid",
    numColumns = 1,
    layout_width = "fill",
    layout_height = "fill",
  },
  {
    Button,
    text = "soy joto",
    onClick = function(view)
      dlg.dismiss()
      vibrator.vibrate(100)
    end,
    layout_width = "wrap_content",
    gravity = 5,
  },
}

dlg = LuaDialog(service)
dlg.View = loadlayout(layout)
grid.adapter = SingleLineAdapter(service, String(enlaces))

grid.onItemClick = function(l, v)
  task(100, function()
    dlg.dismiss()
    local context = activity or service
    vibrator.vibrate(100)
    service.playSoundTick()

    if v.text == enlaces[1] then
      openLink("https://chat.whatsapp.com/EeqtfsbVmUxLxNtUxZuZ5W")
    end
  end)
end

function openLink(url)
  local intent = Intent(Intent.ACTION_VIEW)
  intent.setData(Uri.parse(url))
  context.startActivity(intent)
  service.asyncSpeak("El enlace se ha abierto.")
end

dlg.show()

function onKeyDown(code, event)
  if code == KeyEvent.KEYCODE_BACK then
    dlg.dismiss()
    return true
  end
end
return true