require "import"
import "android.widget.*"
import "android.view.*"
import "android.media.MediaPlayer"
import "java.io.File"
import "com.androlua.LuaDialog"

local mp = MediaPlayer()
local currentIndex = -1
local musicFiles = {}

-- Buscar canciones de Love Shady en todo el almacenamiento principal
local function searchLoveShadySongs(dirPath)
    local dir = File(dirPath)
    local files = {}
    if dir.exists() and dir.isDirectory() then
        local list = dir.listFiles()
        if list then
            for i=0,#list-1 do
                local f = list[i]
                if f.isFile() then
                    local name = f.getName():lower()
                    if (name:match("%.mp3$") or name:match("%.wav$")) and name:match("love") and name:match("shady") then
                        table.insert(files, f.getPath())
                    end
                elseif f.isDirectory() then
                    local subfiles = searchLoveShadySongs(f.getPath())
                    for _, v in ipairs(subfiles) do table.insert(files, v) end
                end
            end
        end
    end
    return files
end

musicFiles = searchLoveShadySongs("/storage/emulated/0/")

local function togglePlay(index)
    if currentIndex == index then
        if mp.isPlaying() then
            mp.pause()
        else
            mp.start()
        end
    else
        if mp.isPlaying() then mp.stop() end
        mp.reset()
        currentIndex = index
        pcall(function()
            mp.setDataSource(musicFiles[index])
            mp.prepare()
            mp.start()
        end)
    end
end

local dlg = LuaDialog(service)
dlg.setTitle("Canciones de Love Shady 🎶")
local layout = {
    LinearLayout,
    orientation="vertical",
    layout_width="fill",
    layout_height="fill",
    padding="16dp",
    {
        ListView,
        id="lvMusic",
        layout_width="fill",
        layout_height="fill"
    }
}
dlg.View = loadlayout(layout)
local adapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, musicFiles)
lvMusic.setAdapter(adapter)
lvMusic.setOnItemClickListener(AdapterView.OnItemClickListener{
    onItemClick=function(parent, view, position, id)
        togglePlay(position+1)
    end
})
dlg.show()