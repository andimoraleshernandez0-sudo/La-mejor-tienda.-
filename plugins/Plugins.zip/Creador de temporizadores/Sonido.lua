function get_script_dir()
local script_path = debug.getinfo(1).source:match("@?(.*/)")
return script_path
end
