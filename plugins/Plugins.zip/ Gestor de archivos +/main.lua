if service.click({
{">Gestor de archivos +",
"Búsqueda por voz<03",
}
})
return true
end