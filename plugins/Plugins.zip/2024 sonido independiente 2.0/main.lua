require "import"
import "android.media.AudioManager"
local audioManager=service.getSystemService(this.AUDIO_SERVICE)

local a= audioManager.isSpeakerphoneOn()
audioManager.setMode(0)
switch a
case false
audioManager.setSpeakerphoneOn(true)
service.speak("Habilitado")

case true
audioManager.setSpeakerphoneOn(false)

service.speak("Deshabilitado")
end
return true