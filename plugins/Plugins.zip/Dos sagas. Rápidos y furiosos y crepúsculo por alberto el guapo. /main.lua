require "import"
import "android.widget.*"
import "android.content.*"
import "android.view.*"
import "com.androlua.*"
import "android.os.Vibrator"
import "android.net.Uri"

-- Contexto
local ctx = activity or service
local vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE)

-- Mensajes de bienvenida y despedida
local MENSAJE_BIENVENIDA = "Hola, bienvenido. Esta experiencia fue creada por Alberto el Guapo."
local MENSAJE_DESPEDIDA  = "Gracias por visitar este plugin. Hasta luego."

-- Función para hablar texto
local function hablar(texto)
  if service and service.asyncSpeak then
    service.asyncSpeak(texto)
  end
end

-- Función para abrir un enlace y cerrar el diálogo
local function abrirEnlace(url)
  if not url or url == "" then
    hablar("El enlace no está disponible.")
    return
  end
  local intent = Intent(Intent.ACTION_VIEW)
  intent.setData(Uri.parse(url))
  ctx.startActivity(intent)
  hablar("Abriendo enlace.")
  if dlg and dlg.dismiss then dlg.dismiss() end
end

-- Enlaces y descripciones
local enlaces = {
  {
    titulo = "Saga Crepúsculo",
    descripcion = "Crepúsculo - saga completa - Google Drive",
    url = "https://drive.google.com/drive/folders/1rXRVp50_dgwW11m_XDlLVw2pouWxx8bP"
  },
  {
    titulo = "Rápidos y Furiosos",
    descripcion = "Rápidos y furiosos - saga - audio latino - Google Drive",
    url = "https://drive.google.com/drive/folders/1EMhs5WwRHTqmjI3SYoXA8rxcNLEFhxN1"
  }
}

-- Construir layout dinámicamente
local layoutBotones = { LinearLayout,
  orientation = "vertical",
  layout_width = "match_parent",
  layout_height = "match_parent",
  padding = "12dp",
}

for i, enlace in ipairs(enlaces) do
  table.insert(layoutBotones, {
    Button,
    text = enlace.titulo,
    layout_width = "match_parent",
    layout_height = "wrap_content",
    layout_marginBottom = "4dp",
    onClick = function() abrirEnlace(enlace.url) end
  })
  table.insert(layoutBotones, {
    TextView,
    text = enlace.descripcion,
    textSize = "14sp",
    layout_width = "match_parent",
    layout_height = "wrap_content",
    paddingBottom = "12dp"
  })
end

-- Botón de cerrar
table.insert(layoutBotones, {
  Button,
  text = "Cerrar",
  layout_width = "wrap_content",
  layout_height = "wrap_content",
  layout_gravity = "end",
  onClick = function()
    hablar(MENSAJE_DESPEDIDA)
    vibrator.vibrate(80)
    if dlg and dlg.dismiss then dlg.dismiss() end
  end
})

-- Crear diálogo
dlg = LuaDialog(service or ctx)
dlg.setTitle("Enlaces de Películas")
dlg.setView(loadlayout(layoutBotones))

-- Mostrar y hablar bienvenida
dlg.show()
hablar(MENSAJE_BIENVENIDA)
vibrator.vibrate(100)

-- Capturar tecla Back
function onKeyDown(code, event)
  if code == KeyEvent.KEYCODE_BACK then
    hablar(MENSAJE_DESPEDIDA)
    vibrator.vibrate(80)
    if dlg and dlg.dismiss then dlg.dismiss() end
    return true
  end
end