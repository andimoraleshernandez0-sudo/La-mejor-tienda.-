-- Plugin creado por Chuy Bautista 
require "import"
import "android.content.Context"
import "android.os.Vibrator"
import "android.widget.*"
import "com.androlua.*"
import "android.content.SharedPreferences"

-- Nombre del archivo de preferencias
local PREFERENCIAS = "encriptadorsupremo"
-- Clave para almacenar la primera ejecución del primer mensaje de bienvenida
local CLAVE_PRIMERA_EJECUCION = "primera_ejecucion"

-- Función para imprimir un mensaje al usuario
function imprimirMensaje(mensaje)
    print(mensaje)  
end

-- Obtener SharedPreferences para verificar si es la primera ejecución
local prefs = service.getSharedPreferences(PREFERENCIAS, Context.MODE_PRIVATE)
local primeraEjecucion = prefs.getBoolean(CLAVE_PRIMERA_EJECUCION, true)

if primeraEjecucion then
    local mensajeBienvenida = "Estas instrucciones solo aparecerán una sola vez. Así que lee con mucha atención.\n" ..
"Hola Androides. ¿Cómo están?\n" ..
"El Encriptador supremo, es un complemento con el cuál podrás encriptar todas tus sintaxis.\n" ..
"Su funcionamiento es muy sencillo. Solamente tienes que aplicar el complemento después de enfocar tu código. Y listo.\n" ..
"Por su atención, graaaaaciiiiaaas. Atentamente: Chuy Bautista.\n"
    imprimirMensaje(mensajeBienvenida)

    -- Marcar que la bienvenida ya se mostró
    local editor = prefs.edit()
    editor.putBoolean(CLAVE_PRIMERA_EJECUCION, false)
    editor.apply()
end

local context = activity or service
local vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)

-- Función para codificar el texto
function encode(input)
    local code = load(input)
    if code then
        return string.dump(code)
    else
        return nil
    end
end

-- Verificar si estamos en un cuadro de edición
if service.isEditView(node) then
    -- Obtener el texto del cuadro de edición
    local texto = this.getText(node)

    -- Verificar si hay texto para codificar
    if texto and texto ~= "" then
        -- Codificar el texto del cuadro de edición
        local encodedText = encode(texto)
        
        if encodedText then
            -- Borrar el texto del cuadro de edición
            this.setText(node, "")

            -- Pegar el texto codificado de nuevo en el cuadro de edición
            this.setText(node, encodedText)

            -- Vibrar después de pegar el texto codificado
            if vibrator.hasVibrator() then
                vibrator.vibrate(100)
            end

            -- Imprimir mensaje de éxito en la consola
            local successMessage = "Código encriptado con éxito! Creado por Chuy Bautista."
            print(successMessage)
        else
            -- Notificar al usuario que no se pudo codificar el código
            service.asyncSpeak("No se pudo encriptar el código. Asegúrate de que el código esté correctamente escrito.")
        end
    else
        -- Notificar al usuario que el cuadro de edición está vacío
        service.asyncSpeak("Enfoca un cuadro de edición en donde esté el código.")
    end
else
    -- Notificar al usuario que debe enfocar un cuadro de edición
    service.asyncSpeak("Enfoca un cuadro de edición en donde esté el código")
end

return true