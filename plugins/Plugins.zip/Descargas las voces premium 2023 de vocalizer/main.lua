require "import"
import "android.widget.*"
import "com.androlua.*"
import "android.content.Context"
import "android.os.Vibrator"
import "android.content.Intent"
import "android.net.Uri"

local context = activity or service
local vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)

function openLink(url)
  local intent = Intent(Intent.ACTION_VIEW)
  intent.setData(Uri.parse(url))
  context.startActivity(intent)
  service.asyncSpeak("El enlace se ha abierto.")
end

local layout = {
  ScrollView,
  {
    LinearLayout,
    orientation = "vertical",
    padding = "16dp",
    {
      Button,
      text = "Cerrar",
      onClick = function()
        dlg.dismiss()
        vibrator.vibrate(100)
      end,
      layout_width = "match_parent",
    },
    {
      TextView,
      text = "Hola te saluda historias loquendo con este complemento podrán descargar las voces 2023 compatible con android 14 15 android 13 12 y 11",
      textSize = "15sp",
      gravity = "center",
      layout_marginBottom = "10dp",
    },
    {
      Button,
      text = "Descargar los archivos desde google drive",
      onClick = function()
        vibrator.vibrate(80)
        dlg.dismiss()
        openLink("https://drive.google.com/drive/folders/1-idlkRB7NJwBU2IkhJZ1Nr8LtUNWHFsk")
      end,
    },
  }
}

dlg = LuaDialog(service)
dlg.setTitle("Descarga las voces premium 2023 compatible con android 13 14 y 15 y compatible con android 12 y 11")
dlg.View = loadlayout(layout)
dlg.show()
return true
