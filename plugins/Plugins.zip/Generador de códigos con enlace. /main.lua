require "import"
import "android.widget.*"
import "android.view.*"
import "com.androlua.LuaDialog"
import "android.os.Vibrator"
import "android.content.Context"
import "android.content.Intent"
import "android.net.Uri"
import "java.io.File"
local context = service
local vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)
local ruta_progreso = tostring(service.getFilesDir()).."/progreso_generador.dat"
local lista_nombres = {}
local lista_links = {}
function verbalizar(texto)
service.speak(texto)
end
function guardarEnArchivo(titulo, desc)
local datos = {
titulo = titulo,
desc = desc,
nombres = lista_nombres,
links = lista_links
}
import "io"
local archivo = io.open(ruta_progreso, "w")
if archivo then
archivo:write(dump(datos))
archivo:close()
verbalizar("El progreso actual ha sido guardado correctamente.")
else
verbalizar("Error al intentar acceder al almacenamiento para guardar el progreso.")
end
end
function cargarProgresoManual()
local archivo = io.open(ruta_progreso, "r")
if archivo then
local contenido = archivo:read("*a")
archivo:close()
local datos = loadstring("return "..contenido)()
if datos then
ed_titulo.text = datos.titulo
ed_desc.text = datos.desc
lista_nombres = datos.nombres
lista_links = datos.links
verbalizar("Se ha recuperado con éxito el último proyecto guardado.")
else
verbalizar("No se ha podido procesar el archivo de guardado.")
end
else
verbalizar("No se encontró ningún proyecto guardado anteriormente para cargar.")
end
end
function limpiarInterfaz()
ed_titulo.text = ""
ed_desc.text = ""
ed_nombre_link.text = ""
ed_url.text = ""
lista_nombres = {}
lista_links = {}
end
function eliminarProyectoCompleto()
if ed_titulo.text == "" and ed_desc.text == "" and #lista_nombres == 0 then
verbalizar("No hay proyecto disponible para eliminar.")
else
limpiarInterfaz()
local f = File(ruta_progreso)
if f.exists() then f.delete() end
verbalizar("El proyecto se ha eliminado.")
end
end
function abrirConSelector(url)
vibrator.vibrate(80)
local intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
local chooser = Intent.createChooser(intent, "Selecciona una aplicación")
chooser.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
service.startActivity(chooser)
end
function construirCodigo(titulo_final, desc_final)
local nombres_str = ""
local links_str = ""
for i=1, #lista_nombres do
nombres_str = nombres_str .. ' "' .. lista_nombres[i] .. '",\n'
links_str = links_str .. ' "' .. lista_links[i] .. '",\n'
end
return [[
require "import"
import "com.androlua.LuaDialog"
import "android.content.Intent"
import "android.net.Uri"
import "android.widget.*"
import "android.view.*"
import "android.os.Vibrator"
import "android.content.Context"
local context = service
local vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)
vibrator.vibrate(100)
local titulo = "]]..titulo_final..[["
local descricao = "]]..desc_final..[["
local nomes = {
]]..nombres_str..[[}
local links = {
]]..links_str..[[}
local layout = {
LinearLayout,
orientation = "vertical",
backgroundColor = 0xFF000000,
padding = "12dp",
{TextView, text = titulo, textColor = 0xFFFFFFFF, textSize = "22sp", gravity = "center", padding = "12dp"},
{TextView, text = descricao, textColor = 0xFFFFFFFF, textSize = "16sp", gravity = "center", padding = "8dp"},
{ListView, id = "lista_v", layout_width = "fill", layout_height = "0dp", layout_weight = 1},
{Button, text = "Cerrar", backgroundColor = 0xFFD32F2F, textColor = 0xFFFFFFFF, layout_width = "fill",
onClick = function()
vibrator.vibrate(100)
dlg.dismiss()
end}
}
dlg = LuaDialog(service).setView(loadlayout(layout))
lista_v.adapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, nomes)
lista_v.onItemClick = function(_,_,pos,_)
vibrator.vibrate(100)
dlg.dismiss()
local intent = Intent(Intent.ACTION_VIEW, Uri.parse(links[pos+1]))
local chooser = Intent.createChooser(intent, "Selecciona una aplicación")
chooser.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
service.startActivity(chooser)
end
dlg.show()
]]
end
local layout_principal = {
RelativeLayout,
layout_width = "fill",
layout_height = "fill",
backgroundColor = 0xFF1A1A1A,
{
LinearLayout,
orientation = "vertical",
layout_width = "fill",
layout_height = "fill",
padding = "16dp",
{
ScrollView,
layout_width = "fill",
layout_weight = 1,
{
LinearLayout,
orientation = "vertical",
{TextView, text = "Generador de Códigos con Enlaces", textSize = "20sp", textColor = 0xFF00E676, gravity = "center", padding = "10dp"},
{EditText, id = "ed_titulo", hint = "Título", textColor = 0xFFFFFFFF, layout_width = "fill"},
{EditText, id = "ed_desc", hint = "Descripción", textColor = 0xFFFFFFFF, layout_width = "fill"},
{EditText, id = "ed_nombre_link", hint = "Nombre del Botón", textColor = 0xFFFFFFFF, layout_width = "fill"},
{EditText, id = "ed_url", hint = "Enlace del Botón", textColor = 0xFFFFFFFF, layout_width = "fill"},
{
HorizontalScrollView,
layout_width = "fill",
layout_marginTop = "20dp",
horizontalScrollBarEnabled = false,
{
LinearLayout,
orientation = "horizontal",
{
Button,
text = "Añadir",
onClick = function()
vibrator.vibrate(60)
if ed_nombre_link.text == "" or ed_url.text == "" then
verbalizar("No hay contenido por añadir. Primeramente, rellene cada cuadro de edición con la información solicitada.")
else
table.insert(lista_nombres, ed_nombre_link.text)
table.insert(lista_links, ed_url.text)
verbalizar("El botón " .. ed_nombre_link.text .. " ha sido añadido a la lista correctamente.")
ed_nombre_link.text = ""; ed_url.text = ""
end
end
},
{
Button,
text = "Cargar último proyecto",
onClick = function()
vibrator.vibrate(60)
cargarProgresoManual()
end
},
{
Button,
text = "Vista Previa",
onClick = function()
vibrator.vibrate(60)
if ed_titulo.text == "" and ed_desc.text == "" and #lista_nombres == 0 then
verbalizar("No hay contenido disponible para visualizar. Primeramente, rellene todos los cuadros de edición con la información solicitada.")
else
local lay_p = {
LinearLayout, orientation = "vertical", backgroundColor = 0xFF000000, padding = "12dp",
{TextView, text = ed_titulo.text, textColor = 0xFFFFFFFF, textSize = "22sp", gravity = "center", padding = "10dp"},
{TextView, text = ed_desc.text, textColor = 0xFFCCCCCC, textSize = "16sp", gravity = "center", padding = "8dp"},
{ListView, id = "lv_p", layout_width = "fill", layout_height = "300dp"},
{Button, text = "Volver", layout_width = "fill",
onClick = function()
vibrator.vibrate(80)
d_p.dismiss()
end}
}
d_p = LuaDialog(service).setView(loadlayout(lay_p))
lv_p.adapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, lista_nombres)
lv_p.onItemClick = function(_,_,pos,_)
vibrator.vibrate(100)
local link_destino = lista_links[pos+1]
d_p.dismiss()
dlg_escritor.dismiss()
abrirConSelector(link_destino)
end
lv_p.onItemLongClick = function(_,_,pos,_)
vibrator.vibrate(100)
local index = pos + 1
local lay_edit = {
LinearLayout, orientation = "vertical", padding = "16dp",
{EditText, id = "edit_n", text = lista_nombres[index], hint = "Nombre del Botón"},
{EditText, id = "edit_l", text = lista_links[index], hint = "Enlace del Botón"}
}
LuaDialog(service).setTitle("Editar Acceso").setView(loadlayout(lay_edit))
.setPositiveButton("Guardar", function()
vibrator.vibrate(60)
lista_nombres[index] = edit_n.text
lista_links[index] = edit_l.text
lv_p.adapter = ArrayAdapter(service, android.R.layout.simple_list_item_1, lista_nombres)
verbalizar("Los cambios en el acceso han sido guardados.")
end).setNegativeButton("Cancelar", function() vibrator.vibrate(60) end).show()
return true
end
d_p.show()
verbalizar("Abriendo la vista previa del proyecto actual.")
end
end
},
{
Button,
text = "Guardar Progreso",
onClick = function()
vibrator.vibrate(60)
if ed_titulo.text == "" and ed_desc.text == "" and #lista_nombres == 0 then
verbalizar("No hay contenido disponible para guardar. Primeramente, rellene todos los cuadros de edición con la información solicitada.")
else
guardarEnArchivo(ed_titulo.text, ed_desc.text)
end
end
},
{
Button,
text = "Eliminar Proyecto",
onClick = function()
vibrator.vibrate(150)
eliminarProyectoCompleto()
end
},
{
Button,
text = "Crear Código",
backgroundColor = 0xFF00E676,
textColor = 0xFF000000,
onClick = function()
vibrator.vibrate(150)
if ed_titulo.text == "" and ed_desc.text == "" and #lista_nombres == 0 then
verbalizar("No es posible generar el código en este momento. Primeramente, llene todos los cuadros de edición con la información solicitada.")
else
local code = construirCodigo(ed_titulo.text, ed_desc.text)
service.copy(code)
verbalizar("código generado y copiado al portapapeles.")
limpiarInterfaz()
end
end
},
}
}
}
},
{
LinearLayout,
layout_width = "fill",
gravity = "right",
{
Button,
text = "Cerrar",
backgroundColor = 0xFFD32F2F,
textColor = 0xFFFFFFFF,
onClick = function()
vibrator.vibrate(100)
verbalizar("cerrando complemento")
dlg_escritor.dismiss()
end
}
}
}
}
dlg_escritor = LuaDialog(service).setView(loadlayout(layout_principal))
vibrator.vibrate(100)
dlg_escritor.show()