if service.click({
{"%Opciones de programa",
"opciones de retroalimentación",
"Temas de sonido",
"Acuática tema - Chuy Bautista",
}
})
return true
end

return true