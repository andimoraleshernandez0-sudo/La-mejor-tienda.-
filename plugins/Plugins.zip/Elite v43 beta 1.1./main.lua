require "import"
import "android.widget.*"
import "android.content.*"
import "android.view.*"
import "android.media.*"
import "android.media.audiofx.*"
import "android.os.*"
import "java.io.File"
import "android.app.AlertDialog"

local context = activity or service
if not _G.player then _G.player = MediaPlayer() end
local player = _G.player

-- --- PERSISTÊNCIA ---
local pref = context.getSharedPreferences("MusicaPro_V43_Beta", 0)
local rutaGuardada = pref.getString("ultima_ruta", tostring(Environment.getExternalStorageDirectory().getAbsolutePath()))
local ultimaCanPath = pref.getString("ultima_can_path", "")
local ultimaPlaylistDir = pref.getString("ultima_playlist_dir", "")
local ultimoMs = pref.getInt("ultimo_ms", 0)
local ultimaPestana = pref.getString("last_tab", "p2") 

local listaExp, listaRep = {}, {}
local idxAct, angulo, anguloFlanger = 1, 0, 0
local m8D, mAleatorio, mBass, m3D, mFlanger = false, false, false, false, false
local bassBoost, virtualizer, estaCambiando = nil, nil, false

-- --- DIÁLOGO DE SAÍDA (TRADUZIDO) ---
function mostrarConfirmacionSalida()
  local alerta = AlertDialog.Builder(context)
  alerta.setTitle("Aviso de Saída")
  alerta.setMessage("Deseja sair do complemento?\n\nSe escolher 'PLANO DE FUNDO', a música e os efeitos continuarão funcionando perfeitamente.")
  
  alerta.setPositiveButton("FECHAR TUDO", {onClick=function() 
    player.stop() 
    dlg.dismiss() 
  end})
  
  alerta.setNegativeButton("PLANO DE FUNDO", {onClick=function() 
    dlg.dismiss() 
  end})
  
  alerta.setNeutralButton("CANCELAR", nil)
  
  local d = alerta.create()
  if not activity then d.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY) end
  d.show()
end

-- --- MOTOR DE ÁUDIO ---
function aplicarFX()
  pcall(function()
    local sid = player.getAudioSessionId()
    if sid <= 0 then return end
    
    if not bassBoost then bassBoost = BassBoost(0, sid) end
    bassBoost.setEnabled(mBass)
    if mBass then bassBoost.setStrength(1000) end
    
    if not virtualizer then virtualizer = Virtualizer(0, sid) end
    virtualizer.setEnabled(m3D)
    if m3D then virtualizer.setStrength(1000) end

    if Build.VERSION.SDK_INT >= 23 and not mFlanger then
      local v = sbV.getProgress() / 10
      local t = sbT.getProgress() / 10
      local pm = PlaybackParams()
      pm.setSpeed(math.max(0.1, v))
      pm.setPitch(math.max(0.1, t))
      player.setPlaybackParams(pm)
    end
  end)
end

function bucle8D()
  if not m8D or not player.isPlaying() then 
    if not m8D then player.setVolume(1.0, 1.0) end
    return 
  end
  local p = math.sin(angulo)
  player.setVolume(math.max(0.1, (1.0-p)/2), math.max(0.1, (1.0+p)/2))
  angulo = angulo + (sb8D.getProgress() / 1200)
  task(25, bucle8D)
end

function bucleFlanger()
  if not mFlanger or not player.isPlaying() then return end
  if Build.VERSION.SDK_INT >= 23 then
    pcall(function()
      local pm = PlaybackParams()
      local osc = 1.0 + (0.12 * math.sin(anguloFlanger))
      pm.setPitch(osc)
      player.setPlaybackParams(pm)
      anguloFlanger = anguloFlanger + 0.25
    end)
  end
  task(45, bucleFlanger)
end

function tocar(i, resumeMs)
  if #listaRep == 0 then return end
  if i < 1 then i = #listaRep end
  if i > #listaRep then i = 1 end
  idxAct = i
  local file = listaRep[idxAct]
  pcall(function()
    player.reset()
    player.setDataSource(file.getAbsolutePath())
    player.prepare()
    if resumeMs then player.seekTo(resumeMs) end
    player.start()
    aplicarFX()
    txtCan.setText(file.getName())
    pref.edit().putString("ultima_can_path", file.getAbsolutePath()).putString("ultima_playlist_dir", file.getParent()).apply()
    if m8D then angulo = 0 bucle8D() end
    if mFlanger then bucleFlanger() end
  end)
end

-- --- INTERFACE V43 BETA (PORTUGUÊS) ---
local layout = {
  LinearLayout, orientation="vertical", layout_width="match_parent", backgroundColor=0xFF000000,
  { -- CABEÇALHO
    LinearLayout, layout_width="match_parent", backgroundColor=0xFF222222, padding="10dp",
    { TextView, text="REPRODUTOR 8D BETA", layout_weight=1, textColor=0xFF00FF00, textSize="14sp" },
    { Button, id="btnSalir", text="SAIR", textColor=0xFFFF4444 },
  },
  { -- NAVEGAÇÃO
    LinearLayout, layout_width="match_parent", backgroundColor=0xFF1A1A1A,
    { Button, id="btnL", text="LISTA", layout_weight=1 },
    { Button, id="btnR", text="PLAYER", layout_weight=1 },
    { Button, id="btnS", text="EFEITOS", layout_weight=1 },
  },
  { -- CONTEÚDO
    FrameLayout, layout_width="match_parent", layout_weight=1,
    { -- P1
      LinearLayout, id="p1", orientation="vertical", visibility=8,
      { ListView, id="lv", layout_width="match_parent", layout_weight=1 },
      { Button, id="btnSubir", text="PASTA ANTERIOR", layout_width="match_parent" }
    },
    { -- P2
      LinearLayout, id="p2", orientation="vertical", padding="20dp", gravity="center", visibility=8,
      { TextView, id="txtCan", text="Não selecionado", textColor=0xFF00FF00, gravity="center" },
      { SeekBar, id="sbProg", layout_width="match_parent", layout_marginTop="20dp" },
      { LinearLayout, layout_width="match_parent", layout_marginTop="15dp",
        { Button, id="btnAnt", text="<<", layout_weight=1 },
        { Button, id="btnPlay", text="PLAY/PAUSE", layout_weight=1 },
        { Button, id="btnSig", text=">>", layout_weight=1 } },
    },
    { -- P3
      ScrollView, id="p3", visibility=8, {
        LinearLayout, orientation="vertical", padding="15dp",
        { Switch, id="sw8D", text="ATIVAR SOM 8D", textColor=0xFFFFFFFF },
        { SeekBar, id="sb8D", layout_width="match_parent", max=100, progress=35 },
        { View, layout_height="10dp" },
        { Switch, id="swFlanger", text="EFEITO FLANGER (AVIÃO)", textColor=0xFFFFCC00 },
        { Switch, id="sw3D", text="SOM ESPACIAL 3D", textColor=0xFFFFFFFF },
        { Switch, id="swBass", text="GRAVES PROFUNDOS", textColor=0xFF00AAFF },
        { View, layout_height="20dp" },
        { TextView, text="VELOCIDADE MANUAL", textColor=0xFFFFFFFF },
        { SeekBar, id="sbV", layout_width="match_parent", max=30, progress=10 },
        { TextView, text="TOM MANUAL (PITCH)", textColor=0xFFFFFFFF },
        { SeekBar, id="sbT", layout_width="match_parent", max=20, progress=10 },
      }
    }
  }
}

function mostrar(id)
  p1.setVisibility(8) p2.setVisibility(8) p3.setVisibility(8)
  _G[id].setVisibility(0)
  pref.edit().putString("last_tab", id).apply()
end

dlg = LuaDialog(context).setView(loadlayout(layout))

-- EVENTOS
btnSalir.onClick=function() mostrarConfirmacionSalida() end
btnL.onClick=function() mostrar("p1") end
btnR.onClick=function() mostrar("p2") end
btnS.onClick=function() mostrar("p3") end
btnSubir.onClick=function() listar(File(rutaGuardada).getParent() or "/sdcard") end
btnAnt.onClick=function() tocar(idxAct-1) end
btnSig.onClick=function() tocar(idxAct+1) end
btnPlay.onClick=function() 
  if player.isPlaying() then player.pause() else player.start() if m8D then bucle8D() end if mFlanger then bucleFlanger() end end 
end

local changeListener = {
  onProgressChanged=function(v,p,f) if f then aplicarFX() end end,
  onStartTrackingTouch=function() end,
  onStopTrackingTouch=function() end
}
sbV.setOnSeekBarChangeListener(changeListener)
sbT.setOnSeekBarChangeListener(changeListener)
sbProg.setOnSeekBarChangeListener{ onStopTrackingTouch=function(v) player.seekTo(v.getProgress()) end }

sw8D.setOnCheckedChangeListener{ onCheckedChanged=function(v,c) m8D = c if c then bucle8D() else player.setVolume(1,1) end end }
swFlanger.setOnCheckedChangeListener{ onCheckedChanged=function(v,c) mFlanger = c if c then bucleFlanger() else aplicarFX() end end }
sw3D.setOnCheckedChangeListener{ onCheckedChanged=function(v,c) m3D = c aplicarFX() end }
swBass.setOnCheckedChangeListener{ onCheckedChanged=function(v,c) mBass = c aplicarFX() end }

function listar(ruta)
  local f = File(ruta)
  if not f.exists() then f = File("/sdcard") end
  pref.edit().putString("ultima_ruta", f.getAbsolutePath()).apply()
  local nombres, lista = {}, {}
  local files = f.listFiles()
  if files then
    local lt = luajava.astable(files)
    table.sort(lt, function(a,b) return a.getName():lower() < b.getName():lower() end)
    for _, a in ipairs(lt) do
      if a.isDirectory() then table.insert(lista, a) table.insert(nombres, "📁 "..a.getName())
      elseif a.getName():lower():find("%.mp3$") then table.insert(lista, a) table.insert(nombres, "🎵 "..a.getName()) end
    end
  end
  listaExp = lista
  lv.setAdapter(ArrayAdapter(context, android.R.layout.simple_list_item_1, nombres))
end

lv.onItemClick=function(l,v,p,i)
  local r = listaExp[p+1]
  if r.isDirectory() then listar(r.getAbsolutePath()) else
    listaRep = {}
    local pFiles = r.getParentFile().listFiles()
    if pFiles then
      local lt = luajava.astable(pFiles)
      table.sort(lt, function(a,b) return a.getName():lower() < b.getName():lower() end)
      for _, arch in ipairs(lt) do
        if arch.getName():lower():find("%.mp3$") then 
          table.insert(listaRep, arch)
          if arch.getAbsolutePath() == r.getAbsolutePath() then idxAct = #listaRep end
        end
      end
    end
    tocar(idxAct) mostrar("p2")
  end
end

listar(rutaGuardada)
if ultimaPlaylistDir ~= "" then
  local f = File(ultimaPlaylistDir)
  local files = f.listFiles()
  if files then
    for _, arch in ipairs(luajava.astable(files)) do
      if arch.getName():lower():find("%.mp3$") then 
        table.insert(listaRep, arch)
        if arch.getAbsolutePath() == ultimaCanPath then idxAct = #listaRep end
      end
    end
  end
end

if player.isPlaying() then
  if m8D then bucle8D() end
  txtCan.setText(File(ultimaCanPath).getName())
elseif ultimaCanPath ~= "" and File(ultimaCanPath).exists() then
  tocar(idxAct, ultimoMs)
  player.pause()
end

mostrar(ultimaPestana)
dlg.show()
