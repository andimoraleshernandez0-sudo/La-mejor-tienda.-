-- ============================================================
--  ENCRIPTADOR DE CÓDIGO LUA - Plugin Jieshuo
--  Toma el código del cuadro de edición enfocado,
--  lo ofusca completamente y lo reemplaza en el mismo cuadro.
--  El código resultante sigue funcionando con normalidad.
-- ============================================================

-- Verificar que haya un cuadro de edición enfocado
if not service.isEditView(node) then
    service.asyncSpeak("Necesitas enfocar un cuadro de edición con código Lua.")
    return true
end

-- Obtener el código del cuadro enfocado
local codigo = service.getText(node)

if not codigo or tostring(codigo):gsub("%s", "") == "" then
    service.asyncSpeak("El cuadro de edición está vacío.")
    return true
end

codigo = tostring(codigo)

service.asyncSpeak("Encriptando código, espera un momento.")

-- ============================================================
--  MOTOR DE OFUSCACIÓN
--  El código se convierte en una cadena de bytes numéricos
--  empaquetada dentro de un load() válido en Lua.
--  Resultado: ilegible para humanos, ejecutable por Lua.
-- ============================================================

-- Paso 1: Convertir cada carácter a su valor numérico
local bytes = {}
for i = 1, #codigo do
    table.insert(bytes, string.byte(codigo, i))
end

-- Paso 2: Aplicar transformación XOR con clave fija derivada
--         de la longitud del código (sin clave externa, auto-contenida)
local clave = (#codigo * 7 + 13) % 127
if clave == 0 then clave = 42 end

local bytesXOR = {}
for i, b in ipairs(bytes) do
    local k = (clave + i * 3) % 127
    if k == 0 then k = 1 end
    table.insert(bytesXOR, b ~ k)
end

-- Paso 3: Construir tabla de bytes ofuscada como string numérica
local partes = {}
for _, v in ipairs(bytesXOR) do
    table.insert(partes, tostring(v))
end
local tablaBytesStr = table.concat(partes, ",")

-- Paso 4: Generar nombres de variables ofuscados
--         (letras y números sin significado)
local function nombreOfu(n)
    local chars = {"l","I","O","0","o","1","i","L"}
    local result = {}
    local x = n
    repeat
        local idx = (x % #chars) + 1
        table.insert(result, 1, chars[idx])
        x = math.floor(x / #chars)
    until x == 0
    return "_" .. table.concat(result) .. "_"
end

local vA = nombreOfu(1)   -- tabla de bytes
local vB = nombreOfu(2)   -- índice/loop
local vC = nombreOfu(3)   -- resultado
local vD = nombreOfu(4)   -- clave calculada
local vE = nombreOfu(5)   -- tamaño original
local vF = nombreOfu(6)   -- función load

-- Paso 5: Construir el código ofuscado final
--         Es Lua válido que al ejecutarse reproduce el original
local codigoOfuscado = table.concat({
    "local " .. vE .. "=" .. tostring(#codigo) .. ";",
    "local " .. vA .. "={" .. tablaBytesStr .. "};",
    "local " .. vD .. "=(" .. vE .. "*7+13)%127;",
    "if " .. vD .. "==0 then " .. vD .. "=42 end;",
    "local " .. vC .. "={};",
    "for " .. vB .. "=1,#" .. vA .. " do ",
    "local _k=(" .. vD .. "+" .. vB .. "*3)%127;",
    "if _k==0 then _k=1 end;",
    vC .. "[" .. vB .. "]=string.char(" .. vA .. "[" .. vB .. "]~_k);",
    "end;",
    "local " .. vF .. "=load(table.concat(" .. vC .. "));",
    "if " .. vF .. " then return " .. vF .. "() end"
}, "")

-- Reemplazar el código en el cuadro de edición enfocado
service.setText(node, codigoOfuscado)

service.asyncSpeak("Listo. El código fue encriptado y sigue funcionando con normalidad.")

return true