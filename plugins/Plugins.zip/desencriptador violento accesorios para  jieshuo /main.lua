require "import"
import "com.androlua.LuaDialog"
import "android.content.Context"
import "android.content.Intent"
import "android.net.Uri"
import "android.widget.*"
import "android.view.*"
import "android.preference.PreferenceManager"

local context = activity or service
local PREF_KEY = "help_screen_shown_for_Encriptadorviolento"
local prefs = PreferenceManager.getDefaultSharedPreferences(context)
local helpShown = prefs.getBoolean(PREF_KEY, false)

if not helpShown then
  -- ========== PRIMERA EJECUCIÓN: Mostrar diálogo de ayuda ==========
  local tituloDialogo = "Encriptador violento"
  local enlaces = {"Únete a accesorios para jieshuo"}
  local urls = {"https://t.me/accesoriosparajieshuo"}

  local helpLayout = {
    ScrollView,
    layout_width = "match_parent",
    layout_height = "match_parent",
    {
      LinearLayout,
      orientation = "vertical",
      padding = "16dp",
      {TextView, text = "Bienvenido al Encriptador violento...", textSize = "16sp", paddingBottom = "16dp"},
      {TextView, text = "Desarrollado por:", textSize = "14sp", textColor = "#CCCCCC"},
      {TextView, text = "Kevin Sánchez", textSize = "16sp", paddingBottom = "12dp"},
      {TextView, text = "Versión:", textSize = "14sp", textColor = "#CCCCCC"},
      {TextView, text = "1.0", textSize = "16sp", paddingBottom = "12dp"},
      {TextView, text = "Nombre:", textSize = "14sp", textColor = "#CCCCCC"},
      {TextView, text = "Encriptador violento", textSize = "16sp", paddingBottom = "12dp"},
      {TextView, text = "Función:", textSize = "14sp", textColor = "#CCCCCC"},
      {TextView, text = "Con este complemento podrás encriptar y desencriptar tus códigos", textSize = "16sp", paddingBottom = "12dp"},
      {TextView, text = "Como usar:", textSize = "14sp", textColor = "#CCCCCC"},
      {TextView, text = "Enfoca tu código en el cuadro de edición y ejecútalo. Si el código ya está encriptado, lo desencriptará automáticamente.", textSize = "16sp", paddingBottom = "12dp"},
      {TextView, text = "Proporcionado por:", textSize = "16sp", paddingBottom = "16dp"},
      {TextView, text = "Accesorios para jieshuo", textSize = "16sp", paddingBottom = "16dp"},
      {TextView, text = "Para más contenido variado, Únete a nuestra comunidad", textSize = "16sp", paddingBottom = "16dp"},
      {GridView, id = "grid", numColumns = 1, layout_width = "fill_parent"},
      {Button, closeHelpBtn, text = "Cerrar y Continuar", layout_width = "wrap_content", layout_gravity = "center", layout_marginTop = "16dp"},
    }
  }

  local helpDlg = LuaDialog(context)
  helpDlg.setTitle(tituloDialogo)
  helpDlg.setView(loadlayout(helpLayout))

  closeHelpBtn.onClick = function(v)
    helpDlg.dismiss()
  end

  openLink = function(v)
    pcall(function()
      local intent = Intent(Intent.ACTION_VIEW)
      intent.setData(Uri.parse(v))
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      startActivity(intent)
      if service then
        service.asyncSpeak("El enlace se ha abierto.")
      end
    end)
  end

  if #enlaces > 0 then
    grid.adapter = ArrayAdapter(android.R.layout.simple_list_item_1, enlaces)
    grid.onItemClick = function(parent, view, position, id)
      task(100, function()
        helpDlg.dismiss()
        local url = urls[position + 1]
        if url then
          openLink(url)
          if activity then
            activity.finish()
          end
        else
          if service then
            service.stopSelf()
          end
        end
      end)
    end
  end

  helpDlg.setOnDismissListener(function()
    prefs.edit().putBoolean(PREF_KEY, true).commit()
    Toast.makeText(context, "Ayuda cerrada. Vuelve a ejecutar para usar el complemento.", Toast.LENGTH_LONG).show()
  end)

  helpDlg.show()
  return true

else
  -- ========== EJECUCIONES SIGUIENTES: Modo encriptación / desencriptación ==========
  require "import"
  import "android.content.Context"
  import "android.os.Vibrator"
  import "com.androlua.*"
  import "android.util.Base64"
  import "android.content.ClipData"
  import "android.content.ClipboardManager"

  local context = activity or service
  local vibrator = context.getSystemService(Context.VIBRATOR_SERVICE)

  local KEY = 90
  local b64_std = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  local b64_my  = "fu+TrNOQUJm4tWbAs0l7jv5RxnowpVzy3c/SHZeGLDaC9hYI1XM2qEg6d8KikFBP"

  -- ─────────────────────────────────────────────
  --  Utilidades compartidas
  -- ─────────────────────────────────────────────

  -- Intercambia caracteres de un alfabeto base64 por otro
  function swap_alphabet(text, from, to)
    local m = {}
    for i = 1, #from do
      m[from:sub(i,i)] = to:sub(i,i)
    end
    return text:gsub(".", m)
  end

  -- Escapa datos binarios a secuencias \ddd decimales
  function escapar_binario(data)
    local result = {}
    for i = 1, #data do
      table.insert(result, string.format("\\%03d", string.byte(data, i)))
    end
    return table.concat(result)
  end

  -- ─────────────────────────────────────────────
  --  DETECCIÓN de código ya encriptado
  -- ─────────────────────────────────────────────

  -- Detecta si el texto ya fue encriptado por este complemento
  -- El patrón es: loadstring("\ddd...") ("payload_b64")
  function esEncriptado(texto)
    return texto:match('^loadstring%("\\%d%d%d') ~= nil
  end

  -- Extrae el payload base64 (argumento entre las comillas del segundo paréntesis)
  function extraerPayload(texto)
    -- Busca el último par de paréntesis con su argumento entre comillas
    return texto:match('%("([A-Za-z0-9+/fu+TrNOQUJm4tWbAs0l7jv5RxnowpVzy3c/SHZeGLDaC9hYI1XM2qEg6d8KikFBP=\n]+)"%)')
  end

  -- ─────────────────────────────────────────────
  --  DESENCRIPTACIÓN
  -- ─────────────────────────────────────────────

  function desencriptarListo(texto)
    local ok, result = pcall(function()

      -- Paso 1: Extraer el payload con el alfabeto personalizado
      local payload = extraerPayload(texto)
      if not payload then
        error("No se pudo extraer el payload encriptado. Verifica que el código sea válido.")
      end

      -- Paso 2: Revertir el swap de alfabeto (personalizado → estándar)
      local b64_standard = swap_alphabet(payload, b64_my, b64_std)

      -- Paso 3: Decodificar Base64 con Android
      local decoded = Base64.decode(b64_standard, 0)

      -- Paso 4: Revertir el shift de bytes (-KEY mod 256)
      local chars = {}
      for i = 0, #decoded - 1 do
        local v = decoded[i]
        if v < 0 then v = v + 256 end   -- byte con signo → sin signo
        v = (v - KEY) % 256              -- shift inverso
        table.insert(chars, string.char(v))
      end

      local source = table.concat(chars)

      -- Comprobar si el resultado es bytecode Lua (empieza con ESC "Lua")
      -- Eso ocurriría solo con encriptaciones hechas con la versión anterior
      -- que usaba string.dump. En ese caso no se puede recuperar el fuente.
      if source:sub(1,1) == "\27" then
        error("Este código fue encriptado con una versión anterior que compila a bytecode.\n"
           .. "El código fuente original no puede recuperarse, pero el código encriptado sigue siendo ejecutable.")
      end

      return source
    end)

    if not ok then
      return nil, tostring(result)
    end
    return result, nil
  end

  -- ─────────────────────────────────────────────
  --  ENCRIPTACIÓN  (versión actualizada: sin string.dump → 100% reversible)
  -- ─────────────────────────────────────────────

  -- Genera el stub auto-desencriptador (el "cerebro binario")
  function obtenerCerebroBinario()
    local code = 'local z = ... \n'
      .. 'local f="' .. b64_std .. '";\n'
      .. 'local k="' .. b64_my .. '";\n'
      .. 'local m={};for i=1,#k do m[k:sub(i,i)]=f:sub(i,i)end;\n'
      .. 'local r=z:gsub(".",m);\n'
      .. '\n'
      .. 'local _=string.char;local d=luajava.bindClass;\n'
      .. 'local function g(h)local s="";for i=1,#h do s=s.._(h[i])end;return s;end;\n'
      .. 'local B=d(g({97,110,100,114,111,105,100,46,117,116,105,108,46,66,97,115,101,54,52}));\n'
      .. '\n'
      .. 'local b=B.decode(r,0);\n'
      .. 'local t=table;local o={};\n'
      .. '\n'
      .. 'for i=0,#b-1 do \n'
      .. '  local v=b[i];\n'
      .. '  if v<0 then v=v+256 end;\n'
      .. '  v=(v-' .. KEY .. ')%256;\n'
      .. '  t.insert(o,_(v))\n'
      .. 'end\n'
      .. 'return loadstring(t.concat(o))()\n'
    return string.dump(loadstring(code))
  end

  -- Encripta el texto fuente (sin compilar a bytecode: 100% desencriptable)
  function encriptarListo(texto)
    if not texto or texto == "" then
      return nil
    end

    local ok, result = pcall(function()
      -- Paso 1: Aplicar shift de bytes al texto fuente directamente (+KEY mod 256)
      --         (ya NO se compila a bytecode para que la desencriptación sea posible)
      local shifted = {}
      for i = 1, #texto do
        local b = string.byte(texto, i)
        shifted[i-1] = (b + KEY) % 256
      end

      -- Paso 2: Codificar en Base64 con Android
      local b64 = Base64.encodeToString(shifted, 2)

      -- Paso 3: Swap alfabeto estándar → personalizado
      local swapped = swap_alphabet(b64, b64_std, b64_my)

      -- Paso 4: Obtener el stub auto-desencriptador y escaparlo
      local stub = obtenerCerebroBinario()
      local escaped = escapar_binario(stub)

      -- Paso 5: Construir el payload auto-desencriptable
      return 'loadstring("' .. escaped .. '")("' .. swapped .. '")'
    end)

    if not ok then
      return nil, "ERROR: " .. tostring(result)
    end
    return result, nil
  end

  -- ─────────────────────────────────────────────
  --  LÓGICA PRINCIPAL: detectar → encriptar o desencriptar
  -- ─────────────────────────────────────────────

  -- Verificar que el foco esté en un campo de texto editable
  if not this.isEditView(node) then
    print("Enfoca un cuadro de edición")
    return true
  end

  -- Obtener el texto del nodo enfocado
  local texto = this.getText(node)
  if not texto or texto == "" then
    print("Cuadro vacío")
    return true
  end

  -- Ignorar si ya es un error previo
  if texto:sub(1, 5) == "ERROR" then
    print(texto or "Fallo")
    return true
  end

  -- ── Rama de DESENCRIPTACIÓN ──────────────────
  if esEncriptado(texto) then
    local fuente, err = desencriptarListo(texto)

    if not fuente then
      print("Error al desencriptar: " .. (err or "desconocido"))
      return true
    end

    -- Intentar pegar el código desencriptado de vuelta
    local setText_ok = this.setText(node, fuente)
    if setText_ok then
      if vibrator and vibrator.hasVibrator() then
        vibrator.vibrate(50)
      end
      print("✔ Script desencriptado y pegado exitosamente")
    else
      this.copy(fuente)
      print("Aviso: Código muy grande, se copió al portapapeles.")
    end

    return true
  end

  -- ── Rama de ENCRIPTACIÓN ─────────────────────
  local codigoFinal, err = encriptarListo(texto)
  if not codigoFinal then
    print("Fallo al encriptar: " .. (err or ""))
    return true
  end

  local setText_ok = this.setText(node, codigoFinal)
  if setText_ok then
    if vibrator and vibrator.hasVibrator() then
      vibrator.vibrate(50)
    end
    print("✔ Script encriptado y pegado exitosamente")
  else
    this.copy(codigoFinal)
    print("Aviso: Código muy grande, se copió al portapapeles.")
  end

  return true
end