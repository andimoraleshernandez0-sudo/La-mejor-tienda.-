-- Jieshuo Constructor: Desencriptador de Alto Nivel
require "import"
import "java.io.File"

-- 1. Definimos la ruta de salida para el código recuperado
local ruta_salida = "/sdcard/Jieshuo_Recuperado.txt"

-- 2. Creamos un "Gancho" (Hook) en la función de carga del sistema
local original_load = load
_G.load = function(chunk, name, mode, env)
    local fuente = ""
    
    -- Si el código viene como string, lo atrapamos directamente
    if type(chunk) == "string" then
        fuente = chunk
    -- Si viene como función (encriptación dinámica), intentamos extraer su volcado
    elseif type(chunk) == "function" then
        local ok, dump = pcall(string.dump, chunk)
        if ok then fuente = dump else fuente = "-- [Error: No se pudo volcar el bytecode]" end
    end

    -- 3. Guardamos el hallazgo en un archivo para que no se pierda
    if fuente ~= "" then
        local f = io.open(ruta_salida, "a+")
        f:write("\n\n--- INICIO DE CAPTURA ---\n")
        f:write(tostring(fuente))
        f:write("\n--- FIN DE CAPTURA ---\n")
        f:close()
        print("¡Código capturado en: " .. ruta_salida)
    end

    -- Devolvemos el control al sistema para que la app no se cierre
    return original_load(chunk, name, mode, env)
end

print("Desencriptador activo. Ejecuta el código encriptado ahora.")