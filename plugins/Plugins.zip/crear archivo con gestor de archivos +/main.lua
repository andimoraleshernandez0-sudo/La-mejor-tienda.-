if service.click({
{">Gestor de archivos +",
"Tarjeta SD",
"Más opciones",
"Nuevo",
"Archivo",
}
})
return true
end