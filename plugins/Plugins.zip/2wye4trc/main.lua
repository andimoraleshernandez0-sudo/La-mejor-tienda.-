lua
local items = {"El Chavo - Ep 1", "El Chavo - Ep 2", "Vacaciones en Acapulco"}
local urls = {"url_video_1", "url_video_2", "url_video_3"}

service.click({
  {"%Lista de Episodios"},
  {"@Explora la vecindad"}
})

-- Función para abrir el video seleccionado
function open_episode(index)
  service.browse(urls[index])
end

