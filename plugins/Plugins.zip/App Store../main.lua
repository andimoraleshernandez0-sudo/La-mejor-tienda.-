require "import"
import "android.widget.*"
import "android.view.View"
import "android.content.Intent"
import "android.net.Uri"

-- 1. Lista de Repositorios
local open_source_repos = {
    {"Cromite F-Droid Repo", "https://www.cromite.org/fdroid/repo"},
    {"F-Droid Main Repository", "https://f-droid.org/repo"},
    {"Futo App Repository", "https://app.futo.org/fdroid/repo"},
    {"microG F-Droid repo", "https://microg.org/fdroid/repo"},
    {"IzzyOnDroid F-Droid Repo", "https://apt.izzysoft.de/fdroid/repo"},
    {"Guardian Project Official", "https://guardianproject.info/fdroid/repo"},
    {"NewPipe Official Repo", "https://archive.newpipe.net/fdroid/repo"},
}

-- Constantes y Enlaces
local FDROID_DOWNLOAD_URL = "https://f-droid.org/F-Droid.apk"

-- Enlaces de Comunidades, Modelo y Tutorial
local COMUNIDAD_DESARROLLADORES_URL = "https://chat.whatsapp.com/IK07M8g1OT33ZLgpYdYuAf?mode=wwt"
local ACCESIBILIDAD_EXTREMA_URL = "https://chat.whatsapp.com/BiPb8VBSzSLGxXZ927wMFX?mode=wwt"
local REAL_COMMUNITY_URL = "https://chat.whatsapp.com/BUFXnP2nH1OIuq9AoxKWAU?mode=ac_t"
local CONOCE_AMIGOS_URL = "https://chat.whatsapp.com/LAocfiVSvflGIZVsvTqZZL?mode=wwt"
local GEMINI_MODEL_URL = "https://gemini.google.com/gem/15JVAlG7LvORTVXPpGw1aNnoSOTzumMB0?usp=sharing"
local TUTORIAL_URL = "https://youtu.be/6Uh3hMAk5zo?si=q48dczVs8eaP4_8l" 

-- Variable para el diálogo principal (permite la acción 'Volver')
local dialog_repos 

-- 2. Función para abrir un URL en el navegador
local function openUrl(url)
    service.openUrl(url) 
end

-- 3. Cuadro de diálogo de Instrucciones para Agregar Repositorios (CORREGIDO: Sin asteriscos)
local function show_instructions_dialog()
    local instructions_message = 
        "Una vez que hayas descargado e instalado el cliente F-Droid, sigue esta ruta para agregar los repositorios:\n\n" ..
        "1. Vuelve a este complemento y copia la URL del repositorio que desees.\n" ..
        "2. Abre la aplicación F-Droid.\n" ..
        "3. Ve a Ajustes.\n" ..
        "4. Toca en Repositorios.\n" ..
        "5. Toca Añadir orígenes adicionales de aplicaciones.\n" ..
        "6. Selecciona Repositorio nuevo.\n" ..
        "7. Pega la URL del repositorio manualmente."

    local dialog_instructions = LuaDialog(activity or service)
    dialog_instructions.setTitle("📝 Instrucciones Importantes (F-Droid)")
    dialog_instructions.setMessage(instructions_message)
    
    -- Botón 1: Vuelve al menú de repositorios
    dialog_instructions.setButton("Volver a Repositorios", function()
        dialog_instructions.dismiss()
        if dialog_repos and dialog_repos.show then
            dialog_repos.show()
        end
    end)
    
    -- Botón 2: Cierra el diálogo completamente
    dialog_instructions.setButton2("Cerrar", function()
        dialog_instructions.dismiss()
    end)
    
    dialog_instructions.show()
end

-- 4. Cuadro de diálogo de Descarga de Cliente
local function show_download_dialog()
    local dialog_download = LuaDialog(activity or service)
    dialog_download.setTitle("⬇️ Descarga la App Cliente")
    dialog_download.setMessage(
        "Para gestionar todos estos repositorios, se recomienda usar el cliente oficial de F-Droid.\n\n" ..
        "¿Deseas descargar el instalador (APK) de F-Droid ahora?"
    )

    -- Botón de DESCARGA
    dialog_download.setButton("Descargar F-Droid APK", function()
        openUrl(FDROID_DOWNLOAD_URL)
        dialog_download.dismiss()
        show_instructions_dialog()
    end)
    
    -- Botón de Cancelar/Regresar
    dialog_download.setButton2("Cancelar", function() 
        dialog_download.dismiss()
        if dialog_repos and dialog_repos.show then
            dialog_repos.show()
        end
    end) 

    dialog_download.show()
end


-- 5. Cuadro de diálogo de Repositorios 
local function show_repos_dialog()
    dialog_repos = LuaDialog(activity or service)
    
    local layout_repos = {
        LinearLayout,
        orientation = "vertical",
        layout_width = "match_parent",
        layout_height = "wrap_content",
        padding = "10dp", 
    }
    
    -- Botón para Acceder a Géminis
    table.insert(layout_repos, {
        Button,
        text = "🤖 Acceder al modelo de Géminis",
        layout_width = "match_parent",
        layout_height = "wrap_content",
        onClick = function()
            openUrl(GEMINI_MODEL_URL)
            dialog_repos.dismiss() 
        end
    })

    -- Botón para descargar el APK cliente
    table.insert(layout_repos, {
        Button,
        text = "⬇️ Descargar App Cliente (F-Droid)",
        layout_width = "match_parent",
        layout_height = "wrap_content",
        onClick = function()
            dialog_repos.dismiss()
            show_download_dialog() 
        end
    })

    -- Separador
    table.insert(layout_repos, {
        TextView,
        text = "\n--- Copiar URL e Instalar Repositorios ---\n", 
        layout_width = "match_parent",
        layout_height = "wrap_content",
        gravity = "center",
    })

    -- Botones para copiar los repositorios
    for _, repo in ipairs(open_source_repos) do
        local name = repo[1]
        local url = repo[2]
        
        table.insert(layout_repos, {
            Button,
            text = name .. " (Copiar URL)",
            layout_width = "match_parent",
            layout_height = "wrap_content",
            onClick = function()
                service.copy(url) 
                service.speak("URL copiada al portapapeles: " .. name)
                dialog_repos.dismiss()
                show_instructions_dialog()
            end
        })
    end
    
    dialog_repos.setTitle("🌐 Repositorios Disponibles (Open Source)")
    dialog_repos.View = loadlayout(layout_repos)
    dialog_repos.setButton("Cerrar", nil)
    dialog_repos.show()
end

-- 6. Cuadro de diálogo de Bienvenida (Sin asteriscos)
local function show_welcome_dialog()
    local dialog_welcome = LuaDialog(activity or service)
    dialog_welcome.setTitle("✨ ¡Hola! Soy Ogmox y te presento mi App Store.")
    
    local ogmox_message = 
        "Hola, ¿qué tal? Soy Ogmox y hoy te presento mi plugin App Store.\n\n" ..
        "Muchos dicen que desarrollar complementos con Inteligencia Artificial para el lector Jieshuo es bien fácil. Entonces, ¿por qué no lo hacen ustedes? ¡Ni madres!\n\n" ..
        "Les doy un consejo para los que alguna vez les dicen que nunca van a poder desarrollar plugins, o para aquellos quienes quieren aprender pero tienen miedo a que no funcione a la primera: ¡tengo la solución!\n\n" ..
        "Espero que aprendas que, jamás a partir de hoy, si te encontraste con este complemento, tendrás que depender de los demás. Crea tus propias ideas y ayuda a la comunidad de Jieshuo a tener más desarrolladores."

    local layout_welcome = {
        LinearLayout,
        orientation = "vertical",
        layout_width = "match_parent",
        layout_height = "wrap_content",
        padding = "15dp",
        {
            TextView,
            text = ogmox_message,
            layout_width = "match_parent",
            layout_height = "wrap_content",
        },
        -- Botón para el Tutorial
        {
            Button,
            text = "▶️ Ver tutorial",
            layout_width = "match_parent",
            layout_height = "wrap_content",
            onClick = function()
                openUrl(TUTORIAL_URL)
                dialog_welcome.dismiss()
            end
        },
        -- Botón 1: Comunidad de Desarrolladores
        {
            Button,
            text = "🤝 Únete a la comunidad de desarrolladores y aprende o aporta recursos para entrenar el modelo",
            layout_width = "match_parent",
            layout_height = "wrap_content",
            onClick = function()
                openUrl(COMUNIDAD_DESARROLLADORES_URL)
                dialog_welcome.dismiss() 
            end
        },
        -- Botón 2: Accesibilidad Extrema
        {
            Button,
            text = "🔊 Únete a Accesibilidad Extrema y motívame a seguir trayéndote complementos de alta gama",
            layout_width = "match_parent",
            layout_height = "wrap_content",
            onClick = function()
                openUrl(ACCESIBILIDAD_EXTREMA_URL)
                dialog_welcome.dismiss() 
            end
        },
        -- Botón 3: Real Community
        {
            Button,
            text = "⭐ Únete a Real Community y motívame a seguirte trayendo los tutoriales que tanto te gustan",
            layout_width = "match_parent",
            layout_height = "wrap_content",
            onClick = function()
                openUrl(REAL_COMMUNITY_URL)
                dialog_welcome.dismiss() 
            end
        },
        -- Botón 4: Conoce amigos
        {
            Button,
            text = "💬 Conoce amigos, comparte y comenta sobre el lector Jieshuo y más",
            layout_width = "match_parent",
            layout_height = "wrap_content",
            onClick = function()
                openUrl(CONOCE_AMIGOS_URL)
                dialog_welcome.dismiss() 
            end
        },
    }

    dialog_welcome.View = loadlayout(layout_welcome)

    -- Botón de "Continuar" que abre el diálogo de repositorios
    dialog_welcome.setButton("Continuar", function()
        dialog_welcome.dismiss()
        show_repos_dialog()
    end)
    
    dialog_welcome.setButton2("Cerrar", nil) 
    dialog_welcome.show()
end

-- 7. Ejecución
show_welcome_dialog()
