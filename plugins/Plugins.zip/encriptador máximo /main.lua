--[[
  ENCRIPTADOR 57 CAPAS — Jieshuo / AndroLua
  ==========================================
  Encripta código Lua con 57 transformaciones encadenadas.
  El resultado es Lua ejecutable válido que se auto-descifra.
  La salida visual usa letras, símbolos y caracteres mixtos,
  sin depender de puros números.
  Marca interna: _57X_
--]]

require "import"
import "android.os.Environment"
import "java.io.File"

local CM = "Gjfhdyfjjjjuuñiiuutti99oootttyuiiiiooooojjyyyutttttukkkkooliuuuuyttrr5uii899oooooyuyktyiiiiiityyyyuuu77uuu888uoooyuyhtttyuiiiuuyyy"
local MARCA = "_57X_"
local BACKUP_DIR = Environment.getExternalStorageDirectory().getPath()
                   .. "/Jieshuo/Plugins/EncBackup/57Capas"

-- ============================================================
-- HELPERS
-- ============================================================
local function guardarBackup(t)
  pcall(function()
    local d = File(BACKUP_DIR)
    if not d.exists() then d.mkdirs() end
    local f = io.open(BACKUP_DIR.."/bk_"..tostring(os.time()):sub(-6)..".txt","w")
    if f then f:write(t); f:close() end
  end)
end

local function aplicarTexto(t)
  local ok = pcall(function() service.setText(node, t) end)
  if not ok then service.copy(t); return false end
  return true
end

local function H(s)
  local h = 0x811C9DC5
  for i = 1, #s do
    h = ((h ~ s:byte(i)) * 0x01000193) & 0xFFFFFFFF
  end
  return h
end

-- ============================================================
-- ALFABETO FINAL: letras + símbolos, 85 chars, sin números al frente
-- ============================================================
local ALFA = "QzWxEcRvTbYnUmIoPlKaJhGfDsAqwertySDFGHjklZXCVBNMiuop!@#&*-_=+<>?~^;:|ABCdEFghIJopqRSTuvwXYZ"
local LA   = #ALFA

-- ============================================================
-- CAPAS DE ENCRIPTADO (operan sobre tablas de bytes)
-- ============================================================

local function c_xorCM(b)
  local r={} local lc=#CM
  for i=1,#b do r[i]=(b[i]~CM:byte(((i-1)%lc)+1))&0xFF end
  return r
end

local function c_sumaAcum(b)
  local r={} local acc=0x5A
  for i=1,#b do
    local v=(b[i]+acc)&0xFF; r[i]=v; acc=(acc+v+i)&0xFF
  end
  return r
end

local function c_rotIzq3(b)
  local r={}
  for i=1,#b do local v=b[i]; r[i]=((v<<3)|(v>>5))&0xFF end
  return r
end

local function c_complemento(b)
  local r={}
  for i=1,#b do r[i]=(~b[i])&0xFF end
  return r
end

local function c_xorIdx(b)
  local seed=H(CM)&0xFF; local r={}
  for i=1,#b do r[i]=(b[i]~((i*seed)&0xFF))&0xFF end
  return r
end

local function c_difusion(b)
  local r={} local prev=0x3C
  for i=1,#b do
    local v=(b[i]+prev)&0xFF; r[i]=v; prev=v
  end
  return r
end

local function c_rotDer5(b)
  local r={}
  for i=1,#b do local v=b[i]; r[i]=((v>>5)|(v<<3))&0xFF end
  return r
end

local function c_xorBloque(b)
  local r={}
  for i=1,#b do
    local blk=math.floor((i-1)/8)
    r[i]=(b[i]~(H(CM.."BLK"..blk)&0xFF))&0xFF
  end
  return r
end

local function c_nibbles(b)
  local r={}
  for i=1,#b do
    local v=b[i]; r[i]=((v&0x0F)<<4)|((v&0xF0)>>4)
  end
  return r
end

local function c_sumaInv(b)
  local r={} local lc=#CM
  local inv={}
  for i=1,lc do inv[i]=CM:byte(lc-i+1) end
  for i=1,#b do r[i]=(b[i]+inv[((i-1)%lc)+1])&0xFF end
  return r
end

local function c_rotArray(b)
  local n=#b; local d=math.max(1,math.floor(n/7))
  local r={}
  for i=1,n do r[i]=b[((i-1+d)%n)+1] end
  return r
end

local function c_fibonacci(b)
  local r={} local fa,fb=1,1
  for i=1,#b do
    r[i]=(b[i]~(fb&0xFF))&0xFF
    fa,fb=fb,(fa+fb)&0xFFFF
  end
  return r
end

local function c_mult(b)
  local k=(H(CM)%254)+3; local r={}
  for i=1,#b do r[i]=(b[i]*k)%256 end
  return r
end

local function c_invBloque4(b)
  local r={}
  for i=1,#b,4 do
    local blk={}
    for j=i,math.min(i+3,#b) do blk[#blk+1]=b[j] end
    for j=#blk,1,-1 do r[#r+1]=blk[j] end
  end
  return r
end

local function c_xorParidad(b)
  local r={}
  local kp=H(CM.."PAR")&0xFF; local ki=H(CM.."IMP")&0xFF
  for i=1,#b do r[i]=(b[i]~(i%2==0 and kp or ki))&0xFF end
  return r
end

local function c_cuadrado(b)
  local r={}
  for i=1,#b do r[i]=(b[i]+(i*i))&0xFF end
  return r
end

local function c_swapAlternos(b)
  local r={table.unpack(b)}
  for i=1,#r-1,2 do r[i],r[i+1]=r[i+1],r[i] end
  return r
end

local function c_xorParcial(b)
  local r={} local s=0
  for i=1,#b do
    s=(s+b[i])&0xFF; r[i]=(b[i]~s)&0xFF
  end
  return r
end

local function c_rotVar(b)
  local r={}
  for i=1,#b do
    local rot=(i-1)%8; local v=b[i]
    r[i]=((v<<rot)|(v>>(8-rot)))&0xFF
  end
  return r
end

-- Capas genéricas con semilla variable
local function cXS(b,sd)
  local r={} local k=H(CM..sd)&0xFF
  for i=1,#b do r[i]=(b[i]~k~(i&0xFF))&0xFF end
  return r
end

local function cSS(b,sd)
  local r={} local k=H(CM..sd)&0xFF
  for i=1,#b do r[i]=(b[i]+k+(i%13))&0xFF end
  return r
end

local function cRS(b,sd)
  local rot=(H(CM..sd)%7)+1; local r={}
  for i=1,#b do
    local v=b[i]; r[i]=((v<<rot)|(v>>(8-rot)))&0xFF
  end
  return r
end

local function cNX(b,sd)
  local r={} local k=H(CM..sd)&0x0F
  for i=1,#b do
    local v=b[i]
    r[i]=(((v>>4)~k)&0x0F)<<4|((v&0x0F)~k)
  end
  return r
end

local function cMS(b,sd)
  local r={} local k=((H(CM..sd)%252)+3)
  for i=1,#b do r[i]=(b[i]*k)%256 end
  return r
end

-- ============================================================
-- PIPELINE 57 CAPAS
-- ============================================================
local function enc57(b)
  b=c_xorCM(b)         b=c_sumaAcum(b)      b=c_rotIzq3(b)
  b=c_invBloque4(b)    b=c_complemento(b)   b=c_xorIdx(b)
  b=c_difusion(b)      b=c_rotDer5(b)       b=c_xorBloque(b)
  b=c_nibbles(b)       b=c_sumaInv(b)       b=c_rotArray(b)
  b=c_fibonacci(b)     b=c_mult(b)          b=c_invBloque4(b)
  b=c_xorParidad(b)    b=c_cuadrado(b)      b=c_swapAlternos(b)
  b=c_xorParcial(b)    b=c_rotVar(b)
  b=cXS(b,"A21")  b=cSS(b,"B22")  b=cRS(b,"C23")  b=cNX(b,"D24")  b=cMS(b,"E25")
  b=cXS(b,"F26")  b=cSS(b,"G27")  b=cRS(b,"H28")  b=cNX(b,"I29")  b=cMS(b,"J30")
  b=c_complemento(b)
  b=cXS(b,"K32")  b=c_sumaAcum(b) b=cRS(b,"L34")  b=c_nibbles(b)  b=cSS(b,"M36")
  b=c_fibonacci(b) b=cXS(b,"N38") b=c_rotDer5(b)  b=cMS(b,"O40")
  b=c_xorIdx(b)   b=cNX(b,"P42")  b=c_cuadrado(b) b=cSS(b,"Q44")  b=c_swapAlternos(b)
  b=cXS(b,"R46")  b=c_difusion(b) b=cRS(b,"S48")  b=c_xorBloque(b) b=cMS(b,"T50")
  b=c_rotIzq3(b)  b=cXS(b,"U52")  b=c_sumaInv(b)  b=cNX(b,"V54")
  b=c_xorParcial(b) b=cSS(b,"W56") b=c_xorCM(b)
  return b
end

-- ============================================================
-- CODIFICACIÓN FINAL: Base mixta letras+símbolos
-- ============================================================
local function encBase(bytes)
  local r={}
  for i=1,#bytes,2 do
    local b1=bytes[i]; local b2=bytes[i+1] or 0
    local n=b1*256+b2
    local c3=(n%LA)+1;       n=math.floor(n/LA)
    local c2=(n%LA)+1;       n=math.floor(n/LA)
    local c1=(n%LA)+1
    r[#r+1]=ALFA:sub(c1,c1)..ALFA:sub(c2,c2)..ALFA:sub(c3,c3)
  end
  return table.concat(r)
end

-- ============================================================
-- SERIALIZAR CLAVE COMO BYTES (para el loader)
-- ============================================================
local function serCM()
  local t={}
  for i=1,#CM do t[i]=tostring(CM:byte(i)) end
  return table.concat(t,",")
end

-- ============================================================
-- GENERAR LOADER LUA EJECUTABLE
-- El loader contiene todo el código para revertir las 57 capas
-- y ejecutar el código original sin que sea visible.
-- ============================================================
local function generarLoader(payload, nOrig)
  local cmS = serCM()
  local alfaE = ALFA:gsub("\\","\\\\"):gsub('"','\\"')
  local payE  = payload:gsub("\\","\\\\"):gsub('"','\\"')

  local L = {}
  local function w(s) L[#L+1]=s end

  w("-- "..MARCA)
  w('local _K={"'..cmS:gsub(",","','")..'"}'  )
  -- corregir: usar tabla numérica
  w("local _K={"..cmS.."}")
  w("local _N="..tostring(nOrig))
  w('local _A="'..alfaE..'"')
  w("local _LA="..tostring(LA))
  w('local _P="'..payE..'"')

  -- reconstruir CM desde bytes
  w("local _CM=''")
  w("for _,v in ipairs(_K) do _CM=_CM..string.char(v) end")

  -- hash
  w("local function _H(s) local h=0x811C9DC5")
  w("  for i=1,#s do h=((h~s:byte(i))*0x01000193)&0xFFFFFFFF end return h end")

  -- decodificar base mixta
  w("local _inv={}")
  w("for i=1,_LA do _inv[_A:sub(i,i)]=i-1 end")
  w("local _raw={}")
  w("for i=1,#_P,3 do")
  w("  local v1=_inv[_P:sub(i,i)] or 0")
  w("  local v2=_inv[_P:sub(i+1,i+1)] or 0")
  w("  local v3=_inv[_P:sub(i+2,i+2)] or 0")
  w("  local n=v1*_LA*_LA+v2*_LA+v3")
  w("  _raw[#_raw+1]=math.floor(n/256)")
  w("  _raw[#_raw+1]=n%256")
  w("end")
  w("while #_raw>_N do table.remove(_raw) end")

  -- funciones inversas
  w("local lc=#_CM")
  -- inv xorCM
  w("local function ixCM(b) local r={} for i=1,#b do r[i]=(b[i]~_CM:byte(((i-1)%lc)+1))&0xFF end return r end")
  -- inv sumaAcum
  w("local function iSA(b) local r={} local a=0x5A for i=1,#b do local v=b[i] r[i]=(v-a)&0xFF a=(a+v+i)&0xFF end return r end")
  -- inv rotIzq3 = rotDer3
  w("local function iRI3(b) local r={} for i=1,#b do local v=b[i] r[i]=((v>>3)|(v<<5))&0xFF end return r end")
  -- complemento = su inversa
  w("local function comp(b) local r={} for i=1,#b do r[i]=(~b[i])&0xFF end return r end")
  -- inv xorIdx
  w("local function ixI(b) local s=_H(_CM)&0xFF local r={} for i=1,#b do r[i]=(b[i]~((i*s)&0xFF))&0xFF end return r end")
  -- inv difusion
  w("local function iDif(b) local r={} local p=0x3C for i=1,#b do r[i]=(b[i]-p)&0xFF p=b[i] end return r end")
  -- inv rotDer5 = rotIzq5
  w("local function iRD5(b) local r={} for i=1,#b do local v=b[i] r[i]=((v<<5)|(v>>3))&0xFF end return r end")
  -- inv xorBloque
  w("local function ixBl(b) local r={} for i=1,#b do local bl=math.floor((i-1)/8) r[i]=(b[i]~(_H(_CM..'BLK'..bl)&0xFF))&0xFF end return r end")
  -- nibbles = su inversa
  w("local function nib(b) local r={} for i=1,#b do local v=b[i] r[i]=((v&0x0F)<<4)|((v&0xF0)>>4) end return r end")
  -- inv sumaInv
  w("local function iSI(b) local r={} local inv={} for i=1,lc do inv[i]=_CM:byte(lc-i+1) end for i=1,#b do r[i]=(b[i]-inv[((i-1)%lc)+1])&0xFF end return r end")
  -- inv rotArray
  w("local function iRA(b) local n=#b local d=math.max(1,math.floor(n/7)) local r={} for i=1,n do r[i]=b[((i-1-d+n)%n)+1] end return r end")
  -- fibonacci = su inversa (xor es involución)
  w("local function iFib(b) local r={} local fa,fb=1,1 for i=1,#b do r[i]=(b[i]~(fb&0xFF))&0xFF fa,fb=fb,(fa+fb)&0xFFFF end return r end")
  -- inv mult (modular inverse)
  w("local function iMlt(b) local k=(_H(_CM)%254)+3 local r={} local function mI(a) local r=1 for _=1,254 do r=(r*a)%256 end return r end local ki=mI(k) for i=1,#b do r[i]=(b[i]*ki)%256 end return r end")
  -- invBloque4 = su inversa
  w("local function iB4(b) local r={} for i=1,#b,4 do local bl={} for j=i,math.min(i+3,#b) do bl[#bl+1]=b[j] end for j=#bl,1,-1 do r[#r+1]=bl[j] end end return r end")
  -- inv xorParidad
  w("local function ixPar(b) local r={} local kp=_H(_CM..'PAR')&0xFF local ki=_H(_CM..'IMP')&0xFF for i=1,#b do r[i]=(b[i]~(i%2==0 and kp or ki))&0xFF end return r end")
  -- inv cuadrado
  w("local function iCuad(b) local r={} for i=1,#b do r[i]=(b[i]-(i*i))&0xFF end return r end")
  -- swapAlternos = su inversa
  w("local function iSwp(b) local r={table.unpack(b)} for i=1,#r-1,2 do r[i],r[i+1]=r[i+1],r[i] end return r end")
  -- inv xorParcial
  w("local function ixP(b) local r={} local s=0 for i=1,#b do r[i]=(b[i]~s)&0xFF s=(s+r[i])&0xFF end return r end")
  -- inv rotVar
  w("local function iRV(b) local r={} for i=1,#b do local rot=(i-1)%8 local v=b[i] r[i]=((v>>rot)|(v<<(8-rot)))&0xFF end return r end")
  -- genéricas inversas
  w("local function ixS(b,sd) local r={} local k=_H(_CM..sd)&0xFF for i=1,#b do r[i]=(b[i]~k~(i&0xFF))&0xFF end return r end")
  w("local function iSs(b,sd) local r={} local k=_H(_CM..sd)&0xFF for i=1,#b do r[i]=(b[i]-k-(i%13))&0xFF end return r end")
  w("local function iRs(b,sd) local rot=(_H(_CM..sd)%7)+1 local r={} for i=1,#b do local v=b[i] r[i]=((v>>rot)|(v<<(8-rot)))&0xFF end return r end")
  w("local function iNx(b,sd) local r={} local k=_H(_CM..sd)&0x0F for i=1,#b do local v=b[i] r[i]=(((v>>4)~k)&0x0F)<<4|((v&0x0F)~k) end return r end")
  w("local function iMs(b,sd) local k=(_H(_CM..sd)%252)+3 local function mI(a) local r=1 for _=1,254 do r=(r*a)%256 end return r end local ki=mI(k) local r={} for i=1,#b do r[i]=(b[i]*ki)%256 end return r end")

  -- PIPELINE INVERSO (capa 57 → capa 1)
  w("local d=_raw")
  w("d=ixCM(d)")        -- inv 57
  w("d=iSs(d,'W56')")   -- inv 56
  w("d=ixP(d)")         -- inv 55
  w("d=iNx(d,'V54')")   -- inv 54
  w("d=iSI(d)")         -- inv 53
  w("d=ixS(d,'U52')")   -- inv 52
  w("d=iRI3(d)")        -- inv 51
  w("d=iMs(d,'T50')")   -- inv 50
  w("d=ixBl(d)")        -- inv 49
  w("d=iRs(d,'S48')")   -- inv 48
  w("d=iDif(d)")        -- inv 47
  w("d=ixS(d,'R46')")   -- inv 46
  w("d=iSwp(d)")        -- inv 45
  w("d=iSs(d,'Q44')")   -- inv 44
  w("d=iCuad(d)")       -- inv 43
  w("d=iNx(d,'P42')")   -- inv 42
  w("d=ixI(d)")         -- inv 41
  w("d=iMs(d,'O40')")   -- inv 40
  w("d=iRD5(d)")        -- inv 39
  w("d=ixS(d,'N38')")   -- inv 38
  w("d=iFib(d)")        -- inv 37
  w("d=iSs(d,'M36')")   -- inv 36
  w("d=nib(d)")         -- inv 35
  w("d=iRs(d,'L34')")   -- inv 34
  w("d=iSA(d)")         -- inv 33
  w("d=ixS(d,'K32')")   -- inv 32
  w("d=comp(d)")        -- inv 31
  w("d=iMs(d,'J30')")   -- inv 30
  w("d=iNx(d,'I29')")   -- inv 29
  w("d=iRs(d,'H28')")   -- inv 28
  w("d=iSs(d,'G27')")   -- inv 27
  w("d=ixS(d,'F26')")   -- inv 26
  w("d=iMs(d,'E25')")   -- inv 25
  w("d=iNx(d,'D24')")   -- inv 24
  w("d=iRs(d,'C23')")   -- inv 23
  w("d=iSs(d,'B22')")   -- inv 22
  w("d=ixS(d,'A21')")   -- inv 21
  w("d=iRV(d)")         -- inv 20
  w("d=ixP(d)")         -- inv 19
  w("d=iSwp(d)")        -- inv 18
  w("d=iCuad(d)")       -- inv 17
  w("d=ixPar(d)")       -- inv 16
  w("d=iB4(d)")         -- inv 15
  w("d=iMlt(d)")        -- inv 14
  w("d=iFib(d)")        -- inv 13
  w("d=iRA(d)")         -- inv 12
  w("d=iSI(d)")         -- inv 11
  w("d=nib(d)")         -- inv 10
  w("d=ixBl(d)")        -- inv 9
  w("d=iRD5(d)")        -- inv 8
  w("d=iDif(d)")        -- inv 7
  w("d=ixI(d)")         -- inv 6
  w("d=comp(d)")        -- inv 5
  w("d=iB4(d)")         -- inv 4
  w("d=iRI3(d)")        -- inv 3
  w("d=iSA(d)")         -- inv 2
  w("d=ixCM(d)")        -- inv 1

  -- ejecutar código recuperado
  w("local ch={} for _,v in ipairs(d) do ch[#ch+1]=string.char(v) end")
  w("local code=table.concat(ch)")
  w("local f,e=load(code)")
  w("if f then f()")
  w("elseif service and service.asyncSpeak then")
  w("  service.asyncSpeak('Error: '..tostring(e))")
  w("end")

  return table.concat(L, "\n")
end

-- ============================================================
-- LÓGICA PRINCIPAL
-- ============================================================
local function main()
  local raw = service.getText(node)
  if not raw or tostring(raw)==""  or tostring(raw)=="null" then
    service.asyncSpeak("No hay texto en el elemento enfocado")
    return
  end

  local texto = tostring(raw)

  if texto:find(MARCA, 1, true) then
    service.asyncSpeak("El código ya está encriptado con 57 capas")
    return
  end

  guardarBackup(texto)

  -- Convertir a bytes
  local bytes = {}
  for i=1,#texto do bytes[i]=texto:byte(i) end

  -- Aplicar 57 capas
  local cifrado = enc57(bytes)

  -- Codificar en base mixta letras+símbolos
  local payload = encBase(cifrado)

  -- Generar loader Lua ejecutable
  local loader = generarLoader(payload, #bytes)

  if aplicarTexto(loader) then
    service.asyncSpeak("Código encriptado en 57 capas. Sigue siendo ejecutable.")
  else
    service.asyncSpeak("Código encriptado copiado al portapapeles.")
  end
end

local ok, err = pcall(main)
if not ok then
  service.asyncSpeak("Error en encriptador 57 capas: "..tostring(err))
end
return true