require "import"

context = service

-- Lista de insultos bien mexas
insultos = {
  "¡Chingas a tu madre!",
  "¡No mames, estás bien pendejo!",
  "¡Vete a la verga pinche meco!",
  "¡Eres más menso que un burro con lentes!",
  "¡Pinche inútil, ni estorbar sabes!",
  "¡Tienes menos luces que una veladora mojada!",
  "¡No sirves ni pa' taco de caca!",
  "¡Parece que te amamantaron con tonayan!",
  "¡Chupas más que una aspiradora vieja!",
  "¡Pendejo con mayúsculas y acento!",
  "¡Tienes menos futuro que un tamal sin masa!",
  "¡Pinche pedazo de estorbo ambulante!",
  "¡Te falta barrio, chavo!",
  "¡Tu IQ es negativo, güey!",
  "¡No das una ni aunque te sobornen!",
  "¡Más falso que abrazo de suegra!",
  "¡Más lento que un caracol en reversa!",
  "¡Eres el chiste que nadie cuenta!",
  "¡Pinche cagada con patas!",
  "¡No das pena, das coraje!",
  "¡No eres inútil, eres decoración!",
  "¡Más seco que beso de monja!",
  "¡Pareces idea de lunes en la mañana!",
  "¡Ni pa' meme sirves!",
  "¡Cagas más que hablas, y eso ya es decir!",
  "¡Te apodan WiFi, porque nunca conectas!",
  "¡Pinche caguengue sin barrio!",
  "¡Más inútil que las tildes en inglés!",
  "¡Más salado que caldo de lágrimas!",
  "¡Tu existencia debería pedir perdón!",
  "¡Puta la que te parió!",
  "¡Más confundido que burro en lancha!",
  "¡Ni un milagro te acomoda!",
  "¡Más torpe que bolillo mojado!",
  "¡Vales menos que el cambio de un chicle!",
  "¡Tu cara parece zona de guerra!",
  "¡Cállate que se me seca el oído!",
  "¡Chillas más que novia dejada!",
  "¡Más ridículo que político en TikTok!",
  "¡Tus neuronas están en huelga!",
  "¡Tienes menos sentido que el reggaetón sin bajo!",
  "¡Te huelen los pensamientos!",
  "¡Pinche espectro del fracaso!",
  "¡Haces ver a un cactus como compañía agradable!",
  "¡Más básico que el pan blanco!",
  "¡Das más vueltas que calzón en lavadora!",
  "¡El burro hablando de orejas!",
  "¡Más inútil que timbre en taxi!",
  "¡Más estéril que intento de explicación tuya!",
  "¡Eres el 'ya merito' hecho persona!",
  "¡Te falta calle y te sobra esquina!",
}

-- Función para leerlos uno tras otro
for i, insulto in ipairs(insultos) do
  service.postSpeak(i * 1500, insulto)
end